package com.hust.capstoneproject.views.renting;

import com.hust.capstoneproject.controller.ViewBikeController;
import com.hust.capstoneproject.views.BaseScreenHandler;
import com.hust.capstoneproject.views.returnbike.ReturnBikeScreenHandler;
import com.hust.capstoneproject.controller.RentBikeController;
import com.hust.capstoneproject.entity.bike.EBike;
import com.hust.capstoneproject.utils.API;
import com.hust.capstoneproject.utils.Configs;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.Label;

import com.hust.capstoneproject.entity.bike.Bike;
import javafx.fxml.Initializable;
import javafx.scene.layout.AnchorPane;
import javafx.stage.Stage;

import java.io.IOException;
import java.net.URL;
import java.time.LocalDateTime;
import java.util.ResourceBundle;

public class RentingBikeScreenHandler extends BaseScreenHandler implements Initializable{
    @FXML
    private Button btn_return;

    @FXML
    private Label lb_bikecode;

    @FXML
    private Label lb_name;

    @FXML
    private Label lb_pin;

    @FXML
    private Label lb_rental;

    @FXML
    private Label lb_type;

    @FXML
    private Label batteryLabel;

    @FXML
    private AnchorPane anchorPin;

    private Bike bike;

    public RentBikeController getRentBikeController() {
        return (RentBikeController) super.getBController();
    }

    public ViewBikeController getBikeController() {
        return (ViewBikeController) super.getBController();
    }

    public RentingBikeScreenHandler(Stage stage, String screenPath, Bike bike) throws IOException {
        super(stage, screenPath);
        this.bike = bike;
        setBikeInfo();
    }

    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
        btn_return.setOnMouseClicked(e->{
            try {
                ReturnBikeScreenHandler returnBikeHandler = new ReturnBikeScreenHandler(this.stage, "/com/hust/capstoneproject/ReturnBikeScreen.fxml", this.bike);
                returnBikeHandler.setPreviousScreen(this);
                returnBikeHandler.show();
            } catch (IOException ex) {
                ex.printStackTrace();
            }
        });
    }

    @Override
    public void show() {
        super.show();
    }

    public void setBikeInfo(){
        this.setBController(new ViewBikeController());
        lb_bikecode.setText(API.bikeIdToBikeCode(bike.getBikeId()));
        lb_rental.setText(bike.getTypeBike().getDepositPrice() + " VND");
        lb_name.setText(bike.getName());
        lb_type.setText(bike.getTypeBike().getTypeName());
        if (bike.getTypeBike().getTypeId() == Configs.EBIKE_ID) {
            EBike ebike = this.getBikeController().getEBikeByBikeId(bike.getBikeId());
            batteryLabel.setText(ebike.getBattery() + "%");
            lb_pin.setVisible(true);
            batteryLabel.setVisible(true);
        }
    }
}
