package com.hust.capstoneproject.common.exception;

public class NotEnoughTransactionInfoException extends PaymentException {
    public NotEnoughTransactionInfoException() {
        super("ERROR: Not Enough Transaction Information");
    }
}
