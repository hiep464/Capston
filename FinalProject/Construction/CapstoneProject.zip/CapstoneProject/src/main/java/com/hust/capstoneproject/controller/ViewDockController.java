package com.hust.capstoneproject.controller;

import com.hust.capstoneproject.dao.bike.BikeDAO;
import com.hust.capstoneproject.dao.dock.DockDAO;
import com.hust.capstoneproject.entity.bike.Bike;
import com.hust.capstoneproject.entity.dock.Dock;

import java.util.List;

/**
 * This {@code ViewDockController} class controls the flow of dock usecase in Capstone project
 * @author tuantv
 */
public class ViewDockController extends BaseController{

    private BikeDAO bikeDAO = BikeDAO.getBikeDAO();
    private DockDAO dockDAO = DockDAO.getDockDAO();

    /**
     * Validate the input name
     * @param name - a {@link String} representing the dock name
     * @return a boolean - {@code true} if the name is valid and {@code false} otherwise
     */
    public boolean validateDockName(String name) {
        String nameRegex = "[a-zA-Z0-9 ]+";
        return name == null || name.matches(nameRegex);
    }

    /**
     * Validate the input address
     * @param address - a {@link String} representing the dock address
     * @return a boolean - {@code true} if the address is valid and {@code false} otherwise
     */
    public boolean validateDockAddress(String address) {
        if(address==null || address.isEmpty())
        {
            return true;
        }
        for(char c: address.toCharArray())
        {
            if(Character.isDigit(c))
            {
                return false;
            }
        }
        return true;
    }

    public List<Dock> getAllDock() {
        return dockDAO.getAllDock();
    }

    public List<Dock> getDockByNameAndAddress(String address, String name) {
        return dockDAO.getDockByNameAndAddress(address, name);
    }

    public List<Bike> getBikeByDockId(int dockId) {
        return bikeDAO.getBikeByDockId(dockId);
    }
}
