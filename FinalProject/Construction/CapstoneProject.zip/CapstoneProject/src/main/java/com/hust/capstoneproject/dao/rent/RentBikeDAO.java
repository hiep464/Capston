package com.hust.capstoneproject.dao.rent;

import com.hust.capstoneproject.entity.db.DBConnect;
import com.hust.capstoneproject.entity.rent.RentBike;
import com.hust.capstoneproject.utils.CloseDB;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

public class RentBikeDAO {
    private static RentBikeDAO rentBikeDAO;

    public static RentBikeDAO getRentBikeDAO() {
        if (rentBikeDAO == null) {
            rentBikeDAO = new RentBikeDAO();
        }
        return rentBikeDAO;
    }

    public boolean insertRentBike(RentBike rentBike) {
        PreparedStatement statement = null;
        try {
            Connection connect = DBConnect.getConnection();
            String sql = "insert into rent_bike(bike_id, rental_at, return_at, total_amount) values (?, ?, ?, ?)";
            statement = connect.prepareCall(sql);
            statement.setInt(1, rentBike.getBike().getBikeId());
            statement.setString(2, rentBike.getRentalAt().toString());
            statement.setString(3, rentBike.getReturnAt().toString());
            statement.setInt(4, rentBike.getTotalAmount());

            statement.execute();
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        } finally {
            CloseDB.closeStatement(statement);
        }
        return true;
    }
}
