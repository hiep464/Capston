package com.hust.capstoneproject.views.dock;

import com.hust.capstoneproject.views.BaseScreenHandler;
import com.hust.capstoneproject.views.bike.BikeScreenHandler;
import com.hust.capstoneproject.views.payment.RentPaymentScreenHandler;
import com.hust.capstoneproject.controller.ViewDockController;
import com.hust.capstoneproject.entity.bike.Bike;
import com.hust.capstoneproject.entity.dock.Dock;
import com.hust.capstoneproject.utils.API;
import javafx.beans.property.SimpleStringProperty;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.stage.Stage;

import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;

/**
 * @author HH
 */
public class DockScreenHandler extends BaseScreenHandler implements Initializable{

    @FXML
    private Button btn_rent;

    @FXML
    private Button btn_back;

    @FXML
    private Button btn_choose;

    @FXML
    private Label lb_abike;

    @FXML
    private Label lb_add;

    @FXML
    private Label lb_area;

    @FXML
    private Label lb_distn;

    @FXML
    private Label lb_empt;

    @FXML
    private Label lb_name;

    @FXML
    private Label lb_wtim;

    @FXML
    private TableView<Bike> table_bike;

    @FXML
    private TableColumn<Bike, String> bike_name;

    @FXML
    private TableColumn<Bike, String> type_bike;

    @FXML
    private TableColumn<Bike, String> deposit_price;

    @FXML
    private TableColumn<Bike, String> bike_code;

    @FXML
    private TextField tf_bikecode;

    private Dock dock;

    public DockScreenHandler(Stage stage, String screenPath, Dock dock) throws IOException {
        super(stage, screenPath);
        this.dock = dock;
        setDockInfo();
        setBController(new ViewDockController());
        showTableListBike();
    }

    public ViewDockController getBController() {
        return (ViewDockController) super.getBController();
    }

    @Override
    public void show() {
        super.show();
    }

    @Override
    public void initialize(URL url, ResourceBundle rb) {

        btn_back.setOnMouseClicked(e->{
            homeScreenHandler.show();
        });
        btn_choose.setOnMouseClicked(e->{
            Bike bike = table_bike.getSelectionModel().getSelectedItem();
            try {
                BikeScreenHandler bikeScreenHandler = new BikeScreenHandler(this.stage,"/com/hust/capstoneproject/BikeInfoScreen.fxml", bike);
                bikeScreenHandler.setPreviousScreen(this);
                bikeScreenHandler.setScreenTitle("Bike Info Screen");
                bikeScreenHandler.show();
            } catch (IOException ex) {
                ex.printStackTrace();
            }
        });

        btn_rent.setOnMouseClicked(e->{
            String bike_code = tf_bikecode.getText().trim();
            int bikeId = API.bikeCodeToBikeId(bike_code);
            try {
                RentPaymentScreenHandler rentPaymentScreenHandler = new RentPaymentScreenHandler(this.stage, "/com/hust/capstoneproject/RentPaymentScreen.fxml", bikeId);
                rentPaymentScreenHandler.setPreviousScreen(this);
                rentPaymentScreenHandler.setScreenTitle("Payment Screen");
                rentPaymentScreenHandler.show();
            } catch (IOException ex) {
                ex.printStackTrace();
            }
        });
    }

    public void setDockInfo(){
        lb_name.setText(dock.getName());
        lb_add.setText(dock.getAddress());
        lb_area.setText(String.valueOf(dock.getArea()));
        lb_abike.setText(String.valueOf(dock.getNumOfAvailableBikes()));
        lb_empt.setText(String.valueOf(dock.getNumOfAvailableSpaces()));
        lb_distn.setText(String.valueOf(dock.getDistance()));
        lb_wtim.setText(String.valueOf(dock.getWalkingTime()));
    }

    public void showTableListBike() {
        dock.setBikeList(getBController().getBikeByDockId(dock.getDockId()));
        ObservableList<Bike> oblistBike = FXCollections.observableArrayList(dock.getBikeList());
        bike_name.setCellValueFactory(new PropertyValueFactory<>("name"));
        type_bike.setCellValueFactory(bikeStringCellDataFeatures -> new SimpleStringProperty(bikeStringCellDataFeatures.getValue().getTypeBike().getTypeName().trim()));
        deposit_price.setCellValueFactory(bikeStringCellDataFeatures -> new SimpleStringProperty(String.valueOf(bikeStringCellDataFeatures.getValue().getTypeBike().getDepositPrice())));
        bike_code.setCellValueFactory(bikeStringCellDataFeatures -> new SimpleStringProperty(new API().bikeIdToBikeCode(bikeStringCellDataFeatures.getValue().getBikeId())));
        table_bike.setItems(oblistBike);
    }
}
