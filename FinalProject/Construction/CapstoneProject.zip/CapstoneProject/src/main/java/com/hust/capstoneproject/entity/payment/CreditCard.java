package com.hust.capstoneproject.entity.payment;

public class CreditCard {
    private String cardCode;
    private String owner;
    private String cvvCode;
    private String dateExpired;

    public CreditCard(String cardCode, String owner, String cvvCode, String dateExpired) {
        super();
        this.cardCode = cardCode;
        this.owner = owner;
        this.cvvCode = cvvCode;
        this.dateExpired = dateExpired;
    }

    @Override
    public String toString() {
        return "CreditCard{" +
                "cardCode='" + cardCode + '\'' +
                ", owner='" + owner + '\'' +
                ", cvvCode='" + cvvCode + '\'' +
                ", dateExpired='" + dateExpired + '\'' +
                '}';
    }
}
