package com.hust.capstoneproject.views.home;

import com.hust.capstoneproject.controller.ViewDockController;
import com.hust.capstoneproject.views.BaseScreenHandler;
import com.hust.capstoneproject.views.dock.DockScreenHandler;
import com.hust.capstoneproject.entity.dock.Dock;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.stage.Stage;

import java.io.IOException;
import java.net.URL;
import java.util.List;
import java.util.ResourceBundle;

public class HomeScreenHandler extends BaseScreenHandler implements Initializable{
    @FXML
    private Button btn_choose;

    @FXML
    private Button btn_find;

    @FXML
    private TableColumn<Dock, String> dockadd;

    @FXML
    private TableColumn<Dock, String> dockname;

    @FXML
    private TableView<Dock> table;

    @FXML
    private TextField nameTF;

    @FXML
    private TextField addressTF;

    public ViewDockController getBController() {
        return (ViewDockController) super.getBController();
    }

    public HomeScreenHandler(Stage stage, String screenPath) throws IOException{
        super(stage, screenPath);
        this.setBController(new ViewDockController());
        List<Dock> listDock = this.getBController().getAllDock();
        showTableListDock(listDock);
    }

    @Override
    public void show() {
        super.show();
    }

    @Override
    public void initialize(URL url, ResourceBundle rb) {
        btn_find.setOnMouseClicked(e -> {
            List<Dock> listDock = this.getBController().getDockByNameAndAddress(addressTF.getText(), nameTF.getText());
            showTableListDock(listDock);
        });

        btn_choose.setOnMouseClicked(e ->{
            try {
                Dock dock = table.getSelectionModel().getSelectedItem();
                if (dock == null) {
                    Alert alert = new Alert(Alert.AlertType.ERROR);
                    alert.setTitle("Dock Null");
                    alert.setContentText("You still haven't selected the dock that you want to view info");
                    alert.showAndWait();
                } else {
                    BaseScreenHandler dockScreenHandler = new DockScreenHandler(this.stage,"/com/hust/capstoneproject/DockInfoScreen.fxml", dock);
                    dockScreenHandler.setHomeScreenHandler(this);
                    dockScreenHandler.setScreenTitle("Dock Info Screen");
                    dockScreenHandler.show();
                }
            } catch (IOException ex) {
                ex.printStackTrace();
            }
        });
    }

    public void showTableListDock(List<Dock> listDock) {
        ObservableList<Dock> oblistDock = FXCollections.observableArrayList(listDock);
        dockname.setCellValueFactory(new PropertyValueFactory<>("name"));
        dockadd.setCellValueFactory(new PropertyValueFactory<>("address"));
        table.setItems(oblistDock);
    }
}
