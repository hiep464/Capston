package com.hust.capstoneproject.views.payment;

import com.hust.capstoneproject.controller.ReturnBikeController;
import com.hust.capstoneproject.entity.rent.RentBike;
import com.hust.capstoneproject.utils.Configs;
import com.hust.capstoneproject.views.BaseScreenHandler;
import com.hust.capstoneproject.views.home.HomeScreenHandler;
import com.hust.capstoneproject.views.renting.RentingBikeScreenHandler;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.stage.Stage;

import java.io.IOException;
import java.net.URL;
import java.time.LocalDateTime;
import java.util.ResourceBundle;

public class ReturnResultScreenHandler extends BaseScreenHandler implements Initializable {
    @FXML
    private Label resultLabel;

    @FXML
    private Label messageLabel;

    @FXML
    private Button okButton;

    public ReturnBikeController getBController() {
        return (ReturnBikeController) super.getBController();
    }

    public ReturnResultScreenHandler (Stage stage, String screenPath, String result, String message) throws IOException {
        super(stage, screenPath);
        setBController(new ReturnBikeController());
        resultLabel.setText(result);
        messageLabel.setText(message);
    }

    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
        okButton.setOnMouseClicked(e-> {
            try {
                if (resultLabel.getText() == Configs.PAYMENT_SUCCESS) {
                    System.out.println(RentBike.getRentBike().toString());
                    this.getBController().insertRentBike(RentBike.getRentBike());
                    HomeScreenHandler homeScreenHandler = new HomeScreenHandler(this.stage,"/com/hust/capstoneproject/HomeScreen.fxml");
                    homeScreenHandler.setScreenTitle("Home Screen");
                    homeScreenHandler.show();
                } else {
                    this.getPreviousScreen().show();
                }
            } catch (IOException ex) {
                ex.printStackTrace();
            }
        });
    }
}
