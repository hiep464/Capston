package com.hust.capstoneproject.dao.bike;

import com.hust.capstoneproject.entity.bike.Bike;
import com.hust.capstoneproject.entity.db.DBConnect;
import com.hust.capstoneproject.entity.typebike.TypeBike;
import com.hust.capstoneproject.utils.CloseDB;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class BikeDAO {
    private static final String TABLE_BIKE = "bike";
    private static final String TABLE_TYPE = "type_bike";

    private static BikeDAO bikeDAO;

    public static BikeDAO getBikeDAO() {
        if (bikeDAO == null) {
            bikeDAO = new BikeDAO();
        }
        return bikeDAO;
    }

    public List<Bike> getBikeByDockId(int dockId) {
        List<Bike> listBike = new ArrayList<>();
        Statement statement = null;
        try {
            Connection connect = DBConnect.getConnection();
            String sql = "select * from bike natural join type_bike where dock_id = " + dockId +
                    " and status = 'NR'";
            statement = connect.createStatement();

            ResultSet result = statement.executeQuery(sql);
            try {
                while (result.next()) {
                    TypeBike typeBike = new TypeBike(result.getInt("type_id"), result.getString("type_name").trim(),
                                        result.getInt("deposit_price"));
                    Bike bike = new Bike(result.getInt("bike_id"), result.getString("name").trim(),
                            result.getString("status"), typeBike, result.getInt("dock_id"));
                    listBike.add(bike);
                }
            } finally {
                closeResultSet(result);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            closeStatement(statement);
        }
        return listBike;
    }

    public Bike getBikeByBikeId(int bikeId) {
        Bike bike = null;
        Statement statement = null;
        try {
            Connection connect = DBConnect.getConnection();
            String sql = "select * from " + TABLE_BIKE + " natural join " + TABLE_TYPE +
                    " where bike_id = " + bikeId;
            statement = connect.createStatement();

            ResultSet result = statement.executeQuery(sql);
            try {
                while (result.next()) {
                    TypeBike typeBike = new TypeBike(result.getInt("type_id"), result.getString("type_name").trim(),
                            result.getInt("deposit_price"));
                    bike = new Bike(result.getInt("bike_id"), result.getString("name").trim(),
                            result.getString("status"), typeBike, result.getInt("dock_id"));
                }
            } finally {
                closeResultSet(result);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            closeStatement(statement);
        }
        return bike;
    }

    public boolean updateBikeStatus(Bike bike) {
        String sql = "update bike set status = 'R' where bike_id = " + bike.getBikeId();
        PreparedStatement preparedStatement = null;
        try {
            Connection connect = DBConnect.getConnection();
            preparedStatement = connect.prepareStatement(sql);

            preparedStatement.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        } finally {
            CloseDB.closeStatement(preparedStatement);
        }
        return true;
    }

    public boolean updateBikeAfterReturn(int bikeId, int dockId) {
        String sql = "update bike set status = 'NR', dock_id = " + dockId + " where bike_id = " + bikeId;
        PreparedStatement preparedStatement = null;
        try {
            Connection connect = DBConnect.getConnection();
            preparedStatement = connect.prepareStatement(sql);

            preparedStatement.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        } finally {
            CloseDB.closeStatement(preparedStatement);
        }
        return true;
    }

    private void closeStatement(Statement statement) {
        try {
            if (statement != null)
                statement.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void closeResultSet(ResultSet result) {
        try {
            result.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
