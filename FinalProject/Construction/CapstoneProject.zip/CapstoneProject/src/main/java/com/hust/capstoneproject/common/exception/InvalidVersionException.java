package com.hust.capstoneproject.common.exception;

public class InvalidVersionException extends PaymentException {
    public InvalidVersionException() {
        super("ERROR: Invalid Version Information!");
    }
}
