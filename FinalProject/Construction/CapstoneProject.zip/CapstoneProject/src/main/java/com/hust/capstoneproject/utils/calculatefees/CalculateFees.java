package com.hust.capstoneproject.utils.calculatefees;

import com.hust.capstoneproject.entity.rent.RentBike;

public interface CalculateFees {
    int calculateRentedFees(RentBike rentBike);
}
