package com.hust.capstoneproject.entity.db;

import com.hust.capstoneproject.utils.Configs;

import java.sql.*;

public class DBConnect {
    private static Connection connect;

    public static Connection getConnection() {
        if (connect != null) {
            return connect;
        } try {
            Class.forName("org.postgresql.Driver");
            connect = DriverManager.getConnection(Configs.DB_URL, Configs.DB_USERNAME, Configs.DB_PASSWORD);
            System.out.println("Connect Successfully");
        } catch (ClassNotFoundException | SQLException e) {
            System.out.println("Connect Failure");
        }
        return connect;
    }

    public static void main(String[] args) {
        DBConnect.getConnection();
    }
}
