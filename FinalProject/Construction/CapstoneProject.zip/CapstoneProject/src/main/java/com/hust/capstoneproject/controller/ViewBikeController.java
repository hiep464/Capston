package com.hust.capstoneproject.controller;

import com.hust.capstoneproject.dao.bike.BikeDAO;
import com.hust.capstoneproject.dao.bike.EBikeDAO;
import com.hust.capstoneproject.entity.bike.Bike;
import com.hust.capstoneproject.entity.bike.EBike;

import java.util.regex.Pattern;

/**
 * ViewBikeController class.
 * @author Quan Phung
*/
public class ViewBikeController extends BaseController {
    private BikeDAO bikeDAO = BikeDAO.getBikeDAO();
    private EBikeDAO eBikeDAO = EBikeDAO.geteBikeDAO();

    /**
     * Return true if user fill true bike code.
     * @param bikecode readable bike code
     * @return boolean
     */
    public boolean validateBikecode(String bikecode) {
        if (bikecode == null) return false;
        return Pattern.matches("^[0-9]{10}$", bikecode);
    }

    public Bike getBikeByBikeId(int bikeId) {
        return bikeDAO.getBikeByBikeId(bikeId);
    }

    public EBike getEBikeByBikeId(int ebikeId) {
        return eBikeDAO.getEBikeByBikeId(ebikeId);
    }
}
