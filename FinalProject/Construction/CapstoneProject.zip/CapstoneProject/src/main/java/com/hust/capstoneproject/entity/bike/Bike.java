package com.hust.capstoneproject.entity.bike;

import com.hust.capstoneproject.dao.bike.BikeDAO;
import com.hust.capstoneproject.entity.dock.Dock;
import com.hust.capstoneproject.entity.typebike.TypeBike;

public class Bike {
    protected int bikeId;
    protected String name;
    protected String status;
    protected TypeBike typeBike;
    protected int dockId;

    public Bike() {

    }

    public Bike(int bikeId, String name, String status,TypeBike typeBike, int dockId) {
        this.bikeId = bikeId;
        this.name = name;
        this.status = status;
        this.typeBike = typeBike;
        this.dockId = dockId;
    }

    public Bike(int bikeId, String name, int dockId) {
        this.bikeId = bikeId;
        this.name = name;
        this.dockId = dockId;
    }

    public Bike(int bikeId, String name, TypeBike typeBike) {
        this.bikeId = bikeId;
        this.name = name;
        this.typeBike = typeBike;
    }

    public int getBikeId() {
        return bikeId;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public TypeBike getTypeBike() {
        return typeBike;
    }

    public int getDockId() {
        return dockId;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    @Override
    public String toString() {
        return "Bike{" +
                "bikeId=" + bikeId +
                ", name='" + name + '\'' +
                ", status='" + status + '\'' +
                ", typeBike=" + typeBike +
                ", dockId=" + dockId +
                '}';
    }
}
