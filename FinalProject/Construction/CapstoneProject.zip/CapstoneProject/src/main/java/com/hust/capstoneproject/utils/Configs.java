package com.hust.capstoneproject.utils;

import javafx.scene.text.Font;
import javafx.scene.text.FontPosture;
import javafx.scene.text.FontWeight;

public class Configs {
    // api constants
    public static final String GET_BALANCE_URL = "https://ecopark-system-api.herokuapp.com/api/card/balance/118609_group1_2020";
    public static final String GET_VEHICLECODE_URL = "https://ecopark-system-api.herokuapp.com/api/get-vehicle-code/1rjdfasdfas";
    public static final String PROCESS_TRANSACTION_URL = "https://ecopark-system-api.herokuapp.com/api/card/processTransaction";
    public static final String RESET_URL = "https://ecopark-system-api.herokuapp.com/api/card/reset";

    public static final String CARD_NUMBER = "vn_group1_2021";
    public static final String CARD_NAME = "Group 1";
    public static final String EXPIRATION_DATE = "11/25";
    public static final String SECURITY_CODE = "483";

    public static final String TOKEN = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJfaWQiOiIxMTg2MDlfZ3JvdXAxXzIwMjAiLCJpYXQiOjE1OTkxMTk5NDl9.y81pBkM0pVn31YDPFwMGXXkQRKW5RaPIJ5WW5r9OW-Y";

    // database Configs
    public static final String DB_NAME = "capstone_project";
    public static final String DB_URL = "jdbc:postgresql://localhost:5432/" + DB_NAME;
    public static final String DB_USERNAME = "postgres";
    public static final String DB_PASSWORD = "duykhanhng";

    public static final int STANDARD_BIKE_ID = 1;
    public static final int EBIKE_ID = 2;
    public static final int TWIN_BIKE_ID = 3;

    public static final String BIKECODE_BONUS = "group1";

    public static String CURRENCY = "VND";
    public static float PERCENT_VAT = 10;

    public static final String PAYMENT_SUCCESS = "PAYMENT SUCCESSFULLY!";
    public static final String PAYMENT_FAIL = "PAYMENT FAILED!";

    // static resource
    public static final String IMAGE_PATH = "assets/images";
    public static final String INVOICE_SCREEN_PATH = "/views/fxml/invoice.fxml";
    public static final String INVOICE_MEDIA_SCREEN_PATH = "/views/fxml/media_invoice.fxml";
    public static final String PAYMENT_SCREEN_PATH = "/views/fxml/payment.fxml";
    public static final String RESULT_SCREEN_PATH = "/views/fxml/result.fxml";
    public static final String SPLASH_SCREEN_PATH = "/views/fxml/splash.fxml";
    public static final String CART_SCREEN_PATH = "/views/fxml/cart.fxml";
    public static final String SHIPPING_SCREEN_PATH = "/views/fxml/shipping.fxml";
    public static final String CART_MEDIA_PATH = "/views/fxml/media_cart.fxml";
    public static final String HOME_PATH  = "/views/fxml/home.fxml";
    public static final String HOME_MEDIA_PATH = "/views/fxml/media_home.fxml";
    public static final String POPUP_PATH = "/views/fxml/popup.fxml";

    public static Font REGULAR_FONT = Font.font("Segoe UI", FontWeight.NORMAL, FontPosture.REGULAR, 24);
}
