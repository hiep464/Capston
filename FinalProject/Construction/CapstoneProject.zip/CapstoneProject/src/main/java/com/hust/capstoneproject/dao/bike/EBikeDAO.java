package com.hust.capstoneproject.dao.bike;

import com.hust.capstoneproject.entity.bike.Bike;
import com.hust.capstoneproject.entity.bike.EBike;
import com.hust.capstoneproject.entity.db.DBConnect;
import com.hust.capstoneproject.entity.typebike.TypeBike;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class EBikeDAO{
    private static EBikeDAO eBikeDAO;

    public static EBikeDAO geteBikeDAO() {
        if (eBikeDAO == null) {
            eBikeDAO = new EBikeDAO();
        }
        return eBikeDAO;
    }

    private static final String TABLE_BIKE = "bike";
    private static final String TABLE_EBIKE = "ebike";

    public EBike getEBikeByBikeId(int ebikeId) {
        EBike ebike = null;
        Statement statement = null;
        try {
            Connection connect = DBConnect.getConnection();
            String sql = "select * from " + TABLE_BIKE + ", " + TABLE_EBIKE +
                    " where bike_id = ebike_id and bike_id = " + ebikeId;
            statement = connect.createStatement();

            ResultSet result = statement.executeQuery(sql);
            try {
                while (result.next()) {
                    ebike = new EBike(result.getInt("bike_id"), result.getString("name").trim(),
                            result.getInt("dock_id"), result.getInt("battery"),
                            result.getString("license_plate").trim());
                }
            } finally {
                closeResultSet(result);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            closeStatement(statement);
        }
        return ebike;
    }

    private void closeStatement(Statement statement) {
        try {
            if (statement != null)
                statement.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void closeResultSet(ResultSet result) {
        try {
            result.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
