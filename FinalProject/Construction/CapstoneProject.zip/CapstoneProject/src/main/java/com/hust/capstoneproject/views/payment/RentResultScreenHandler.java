package com.hust.capstoneproject.views.payment;

import com.hust.capstoneproject.entity.rent.RentBike;
import com.hust.capstoneproject.views.BaseScreenHandler;
import com.hust.capstoneproject.views.renting.RentingBikeScreenHandler;
import com.hust.capstoneproject.controller.RentBikeController;
import com.hust.capstoneproject.entity.bike.Bike;
import com.hust.capstoneproject.utils.Configs;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.stage.Stage;

import java.io.IOException;
import java.net.URL;
import java.time.LocalDateTime;
import java.util.ResourceBundle;

public class RentResultScreenHandler extends BaseScreenHandler implements Initializable {
    @FXML
    private Label resultLabel;

    @FXML
    private Label messageLabel;

    @FXML
    private Button okButton;

    private Bike bike;

    public RentBikeController getBController() {
        return (RentBikeController) super.getBController();
    }

    public RentResultScreenHandler(Stage stage, String screenPath, String result, String message, Bike bike) throws IOException {
        super(stage, screenPath);
        this.bike = bike;
        setBController(new RentBikeController());
        resultLabel.setText(result);
        messageLabel.setText(message);
    }

    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
        okButton.setOnMouseClicked(e-> {
            try {
                if (resultLabel.getText() == Configs.PAYMENT_SUCCESS) {
                    RentBike.getRentBike().setRentalAt();
                    RentBike.getRentBike().setBike(bike);
                    this.getBController().updateBikeStatus(bike);
                    RentingBikeScreenHandler rentingBikeScreenHandler = new RentingBikeScreenHandler(this.stage,"/com/hust/capstoneproject/RentingBikeInfoScreen.fxml", bike);
                    rentingBikeScreenHandler.setScreenTitle("Renting Bike Screen");
                    rentingBikeScreenHandler.show();
                } else {
                    this.getPreviousScreen().show();
                }
            } catch (IOException ex) {
                ex.printStackTrace();
            }
        });
    }
}
