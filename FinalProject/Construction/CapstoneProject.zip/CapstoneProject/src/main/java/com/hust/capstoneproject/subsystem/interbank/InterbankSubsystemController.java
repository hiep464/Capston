package com.hust.capstoneproject.subsystem.interbank;

import com.google.gson.GsonBuilder;
import com.hust.capstoneproject.common.exception.*;
import com.hust.capstoneproject.entity.payment.CreditCard;
import com.hust.capstoneproject.entity.payment.PaymentTransaction;
import com.hust.capstoneproject.utils.Configs;
import com.hust.capstoneproject.utils.MyMap;
import com.hust.capstoneproject.utils.Utils;
import com.google.gson.Gson;

import java.util.Map;

public class InterbankSubsystemController {
    private static final String APP_CODE = "CXwRfCajyxQ=";
    private static final String SECRET_KEY = "BEIIxVkcrgo=";
    private static final String PAY_COMMAND = "pay";
    private static final String REFUND_COMMAND = "refund";
    private static final String VERSION = "1.0.1";

    private static InterbankBoundary interbankBoundary = new InterbankBoundary();

    public static PaymentTransaction refund(CreditCard card, String amount, String contents) {
        Map<String, Object> transaction = new MyMap();

        try {
            transaction.putAll(MyMap.toMyMap(card));
        } catch (IllegalArgumentException | IllegalAccessException e) {
            // TODO Auto-generated catch block
            throw new InvalidCardException();
        }
        transaction.put("command", REFUND_COMMAND);
        transaction.put("transactionContent", contents);
        transaction.put("amount", amount);
        transaction.put("createdAt", Utils.getToday());

        Map<String, Object> requestMap = new MyMap();
        requestMap.put("version", VERSION);
        requestMap.put("transaction", transaction);
        requestMap.put("appCode", APP_CODE);
        requestMap.put("hashCode", Utils.md5(SECRET_KEY));

        Gson gson = new GsonBuilder().disableHtmlEscaping().create();
        String requestJson = gson.toJson(requestMap);
        String responseText = interbankBoundary.query(Configs.PROCESS_TRANSACTION_URL, requestJson);

        Map<String, Object> response = null;
        try {
            response = MyMap.toMap(responseText);
        } catch (IllegalArgumentException e) {
            e.printStackTrace();
            throw new UnrecognizedException();
        }

        return makePaymentTransaction(response);
    }

    public static PaymentTransaction payOrder(CreditCard card, String amount, String contents) {
        Map<String, Object> transaction = new MyMap();

        try {
            transaction.putAll(MyMap.toMyMap(card));
        } catch (IllegalArgumentException | IllegalAccessException e) {
            // TODO Auto-generated catch block
            throw new InvalidCardException();
        }
        transaction.put("command", PAY_COMMAND);
        transaction.put("transactionContent", contents);
        transaction.put("amount", amount);
        transaction.put("createdAt", Utils.getToday());

        Map<String, Object> requestMap = new MyMap();
        requestMap.put("version", VERSION);
        requestMap.put("transaction", transaction);
        requestMap.put("appCode", APP_CODE);
        requestMap.put("hashCode", Utils.md5(SECRET_KEY));

        Gson gson = new GsonBuilder().disableHtmlEscaping().create();
        String requestJson = gson.toJson(requestMap);
        String responseText = interbankBoundary.query(Configs.PROCESS_TRANSACTION_URL, requestJson);

        Map<String, Object> response = null;
        try {
            response = MyMap.toMap(responseText);
        } catch (IllegalArgumentException e) {
            e.printStackTrace();
            throw new UnrecognizedException();
        }

        return makePaymentTransaction(response);
    }

    private static PaymentTransaction makePaymentTransaction(Map<String, Object> response) {
        PaymentTransaction trans = null;
        if (response.get("transaction") == null) {
            trans = new PaymentTransaction((String) response.get("errorCode"));
        } else {
            Map<String, Object> transaction = (Map) response.get("transaction");
            System.out.println(response.get("transaction").toString());
            CreditCard card = new CreditCard((String) transaction.get("cardCode"), (String) transaction.get("owner"),
                    (String) transaction.get("cvvCode"), (String) transaction.get("dateExpired"));
            trans = new PaymentTransaction((String) response.get("errorCode"), card,
                    (String) transaction.get("transactionId"), (String) transaction.get("transactionContent"),
                    (String) transaction.get("amount"), (String) transaction.get("createdAt"));
        }

        switch (trans.getErrorCode()) {
            case "00":
                break;
            case "01":
                throw new InvalidCardException();
            case "02":
                throw new NotEnoughBalanceException();
            case "03":
                throw new InternalServerErrorException();
            case "04":
                throw new SuspiciousTransactionException();
            case "05":
                throw new NotEnoughTransactionInfoException();
            case "06":
                throw new InvalidVersionException();
            case "07":
                throw new InvalidTransactionAmountException();
            default:
                throw new UnrecognizedException();
        }

        return trans;
    }

    public static void main(String[] args) {
        CreditCard card = new CreditCard("vn_group1_2021", "Group 1", "483", "1125");
        String amount = "5000000";
        String contents = "haha";
        System.out.println(payOrder(card, amount, contents).toString());
//        System.out.println(refund(card, amount, contents));
    }
}
