package com.hust.capstoneproject.subsystem;

import com.hust.capstoneproject.entity.payment.CreditCard;
import com.hust.capstoneproject.entity.payment.PaymentTransaction;
import com.hust.capstoneproject.subsystem.interbank.InterbankSubsystemController;

/***
 * The {@code InterbankSubsystem} class is used to communicate with the
 * Interbank to make transaction.
 *
 * @author DuyKhanh
 *
 */
public class InterbankSubsystem implements InterbankInterface{
    /**
     * Represent the controller of the subsystem
     */
    private InterbankSubsystemController ctrl;

    /**
     * Initializes a newly created {@code InterbankSubsystem} object so that it
     * represents an Interbank subsystem.
     */
    public InterbankSubsystem() {
        String str = new String();
        this.ctrl = new InterbankSubsystemController();
    }

    public PaymentTransaction payOrder(CreditCard card, String amount, String contents) {
        PaymentTransaction transaction = ctrl.payOrder(card, amount, contents);
        return transaction;
    }

    public PaymentTransaction refund(CreditCard card, String amount, String contents) {
        PaymentTransaction transaction = ctrl.refund(card, amount, contents);
        return transaction;
    }
}
