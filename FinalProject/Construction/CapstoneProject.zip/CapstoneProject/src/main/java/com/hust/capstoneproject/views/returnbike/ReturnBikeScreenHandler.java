package com.hust.capstoneproject.views.returnbike;

import com.hust.capstoneproject.views.BaseScreenHandler;
import com.hust.capstoneproject.controller.ReturnBikeController;
import com.hust.capstoneproject.entity.bike.Bike;
import com.hust.capstoneproject.entity.dock.Dock;
import com.hust.capstoneproject.entity.rent.RentBike;
import com.hust.capstoneproject.views.rent_bike.TransactionInfoScreenHandler;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.stage.Stage;

import java.io.IOException;
import java.net.URL;
import java.util.List;
import java.util.ResourceBundle;

public class ReturnBikeScreenHandler extends BaseScreenHandler implements Initializable {
    @FXML
    private Button btn_back;

    @FXML
    private Button btn_confirm;

    @FXML
    private TableColumn<Dock, Float> cl_dstn;

    @FXML
    private TableColumn<Dock, String> cl_name;

    @FXML
    private TableColumn<Dock, Integer> cl_space;

    @FXML
    private TableColumn<Dock, Float> cl_address;

    @FXML
    private TableView<Dock> table;

    private Bike bike;

    public ReturnBikeController getBController() {
        return (ReturnBikeController) super.getBController();
    }

    public ReturnBikeScreenHandler(Stage stage, String screenPath, Bike bike) throws IOException {
        super(stage, screenPath);
        this.bike = bike;
        setBController(new ReturnBikeController());
        List<Dock> listDock = this.getBController().getAllDockToReturnBike();
        showTableListDock(listDock);
    }

    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
        btn_back.setOnMouseClicked(e->{
            this.getPreviousScreen().show();
        });

        btn_confirm.setOnMouseClicked(e->{
            RentBike.getRentBike().setReturnAt();
            Dock dock = table.getSelectionModel().getSelectedItem();
            if (dock == null) {
                Alert alert = new Alert(Alert.AlertType.ERROR);
                alert.setTitle("Dock Null");
                alert.setContentText("You still haven't selected the dock that you want to return bike");
                alert.showAndWait();
            } else {
                Alert alert = new Alert(Alert.AlertType.CONFIRMATION);
                alert.setTitle("Return Bike");
                alert.setContentText("Do you want to return bike in dock " + dock.getName() + "?");
                ButtonType okButton = new ButtonType("Yes", ButtonBar.ButtonData.YES);
                ButtonType noButton = new ButtonType("No", ButtonBar.ButtonData.NO);
                alert.getButtonTypes().setAll(okButton, noButton);
                alert.showAndWait().ifPresent(type -> {
                    if (type.getButtonData() == ButtonBar.ButtonData.YES) {
                        this.getBController().updateBikeAfterReturn(bike.getBikeId(), dock.getDockId());
                        try {
                            TransactionInfoScreenHandler invoiceScreenHandler = new TransactionInfoScreenHandler(this.stage, "/com/hust/capstoneproject/TransactionInfoScreen.fxml");
                            invoiceScreenHandler.setScreenTitle("Invoice Screen");
                            invoiceScreenHandler.show();
                        } catch (IOException ex) {
                            ex.printStackTrace();
                        }
                    }
                });
            }
        });
    }

    public void showTableListDock(List<Dock> listDock) {
        ObservableList<Dock> oblistDock = FXCollections.observableArrayList(listDock);
        cl_name.setCellValueFactory(new PropertyValueFactory<>("name"));
        cl_address.setCellValueFactory(new PropertyValueFactory<>("address"));
        cl_dstn.setCellValueFactory(new PropertyValueFactory<>("distance"));
        cl_space.setCellValueFactory(new PropertyValueFactory<>("numOfAvailableSpaces"));
        table.setItems(oblistDock);
    }
}
