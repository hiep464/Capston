package com.hust.capstoneproject.views.payment;
import com.hust.capstoneproject.controller.ViewBikeController;
import com.hust.capstoneproject.views.BaseScreenHandler;
import com.hust.capstoneproject.controller.PaymentController;
import com.hust.capstoneproject.entity.bike.Bike;
import com.hust.capstoneproject.entity.bike.EBike;
import com.hust.capstoneproject.utils.Configs;
import javafx.fxml.FXML;
import javafx.scene.control.*;
import javafx.stage.Stage;

import java.io.IOException;
import java.util.Map;

/**
 * @author HH
 */
public class RentPaymentScreenHandler extends BaseScreenHandler {

    @FXML
    private Label batteryLabel;

    @FXML
    private Button btn_back;

    @FXML
    private Button btn_confirm;

    @FXML
    private Label lb_btr;

    @FXML
    private Label lb_license;

    @FXML
    private Label lb_lspl;

    @FXML
    private Label lb_price;

    @FXML
    private Label lb_type;

    @FXML
    private TextArea ta_content;

    @FXML
    private TextField tf_ExDate;

    @FXML
    private TextField tf_cardname;

    @FXML
    private TextField tf_cardnum;

    @FXML
    private TextField tf_secucode;

    private Bike bike;
    private int bikeId;

    public PaymentController getPaymentController() {
        return (PaymentController) super.getBController();
    }

    public ViewBikeController getBikeController() {
        return (ViewBikeController) super.getBController();
    }

    public RentPaymentScreenHandler(Stage stage, String screenPath, int bikeId) throws IOException {
        super(stage, screenPath);
        this.bikeId = bikeId;
        setBController(new ViewBikeController());
        this.bike = this.getBikeController().getBikeByBikeId(bikeId);
        setBikeInfo();

        btn_confirm.setOnMouseClicked(e->{
            try {
                confirmToPayMoney();
            } catch (Exception exp) {
                exp.printStackTrace();
            }
        });

        btn_back.setOnMouseClicked(e->{
            this.getPreviousScreen().show();
        });
    }

    public void setBikeInfo() {
        lb_type.setText(bike.getTypeBike().getTypeName());
        lb_price.setText(bike.getTypeBike().getDepositPrice() + "VND");
        if (bike.getTypeBike().getTypeId() == Configs.EBIKE_ID) {
            EBike ebike = this.getBikeController().getEBikeByBikeId(bike.getBikeId());
            lb_lspl.setText(ebike.getLicensePlate());
            batteryLabel.setText(ebike.getBattery() + "%");
            lb_btr.setVisible(true);
            batteryLabel.setVisible(true);
            lb_license.setVisible(true);
            lb_lspl.setVisible(true);
        }
    }

    public void confirmToPayMoney() throws IOException {
        this.setBController(new PaymentController());
        PaymentController ctrl = this.getPaymentController();
        Map<String, String> response = ctrl.payOrder(String.valueOf(bike.getTypeBike().getDepositPrice()), ta_content.getText().trim(),
                tf_cardnum.getText().trim(), tf_cardname.getText().trim(), tf_ExDate.getText().trim(), tf_secucode.getText().trim());
        BaseScreenHandler resultScreen = new RentResultScreenHandler(this.stage, "/com/hust/capstoneproject/RentResultScreen.fxml",
                response.get("RESULT"), response.get("MESSAGE"), bike);
        resultScreen.setPreviousScreen(this);
        resultScreen.setScreenTitle("Result Screen");
        resultScreen.show();
    }
}
