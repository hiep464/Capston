package com.hust.capstoneproject.utils.calculatefees.impl;

import com.hust.capstoneproject.entity.rent.RentBike;
import com.hust.capstoneproject.utils.calculatefees.CalculateFees;

import java.time.temporal.ChronoUnit;

public class ProCalculateFees implements CalculateFees {
    @Override
    public int calculateRentedFees(RentBike rentBike) {
        int minutes  = (int) ChronoUnit.MINUTES.between(rentBike.getRentalAt(),rentBike.getReturnAt());
        System.out.println(minutes);
        if (minutes<=10) return 0;
        else if (minutes<=30) return 10000;
        else {
            int result = (minutes-30)/15+1;
            if ((minutes-30)%15==0) return 10000+(result-1)*3000;
            else return 10000+result*3000;
        }
    }
}
