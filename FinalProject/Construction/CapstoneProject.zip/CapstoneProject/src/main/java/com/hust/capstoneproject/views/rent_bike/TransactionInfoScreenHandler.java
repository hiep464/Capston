package com.hust.capstoneproject.views.rent_bike;

import com.hust.capstoneproject.controller.PaymentController;
import com.hust.capstoneproject.controller.ReturnBikeController;
import com.hust.capstoneproject.utils.Configs;
import com.hust.capstoneproject.views.BaseScreenHandler;
import com.hust.capstoneproject.utils.calculatefees.impl.NormalCalculateFees;
import com.hust.capstoneproject.utils.calculatefees.impl.ProCalculateFees;
import com.hust.capstoneproject.entity.rent.RentBike;
import com.hust.capstoneproject.views.payment.ReturnPaymentScreenHandler;
import javafx.fxml.Initializable;
import javafx.stage.Stage;

import java.io.IOException;
import java.net.URL;
import java.util.Map;
import java.util.ResourceBundle;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.Label;

public class TransactionInfoScreenHandler extends BaseScreenHandler implements Initializable{
    @FXML
    private Button btn_ok;

    @FXML
    private Label lb_fees;

    @FXML
    private Label lb_name;

    @FXML
    private Label lb_price;

    @FXML
    private Label lb_renAt;

    @FXML
    private Label lb_retAt;

    @FXML
    private Label lb_type;

    @FXML
    private Label vndLabel;

    public ReturnBikeController getBController() {
        return (ReturnBikeController) super.getBController();
    }

    public TransactionInfoScreenHandler(Stage stage, String screenPath) throws IOException {
        super(stage, screenPath);
        setBController(new ReturnBikeController());
        vndLabel.setVisible(true);
        setInvoiceInfo();
    }

    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
        btn_ok.setOnMouseClicked(e->{
            try {
                refundMoney();
                BaseScreenHandler returnBikePaymentScreenHandler = new ReturnPaymentScreenHandler(stage, "/com/hust/capstoneproject/ReturnPaymentScreen.fxml",
                        RentBike.getRentBike().getBike().getTypeBike().getDepositPrice(), Integer.parseInt(lb_fees.getText()));
                returnBikePaymentScreenHandler.setScreenTitle("Payment Screen");
                returnBikePaymentScreenHandler.show();
            } catch (IOException ex) {
                ex.printStackTrace();
            }
        });
    }

    public void setInvoiceInfo(){
        lb_name.setText(RentBike.getRentBike().getBike().getName());
        lb_type.setText(RentBike.getRentBike().getBike().getTypeBike().getTypeName());
        lb_price.setText(RentBike.getRentBike().getBike().getTypeBike().getDepositPrice() + "VND");
        lb_renAt.setText(RentBike.getRentBike().getRentalAt().toString());
        lb_retAt.setText(RentBike.getRentBike().getReturnAt().toString());
        if (RentBike.getRentBike().getBike().getTypeBike().getTypeId()==1){
            this.getBController().setCalculateFees(new NormalCalculateFees());
            int totalAmount = this.getBController().calRentedFees(RentBike.getRentBike());
            lb_fees.setText(String.valueOf(totalAmount));
            RentBike.getRentBike().setTotalAmount(totalAmount);
        } else {
            this.getBController().setCalculateFees(new ProCalculateFees());
            int totalAmount = this.getBController().calRentedFees(RentBike.getRentBike());
            lb_fees.setText(String.valueOf(totalAmount));
            RentBike.getRentBike().setTotalAmount(totalAmount);
        }
    }

    public void refundMoney() {
        PaymentController ctrl = new PaymentController();
        Map<String, String> response = ctrl.refund(String.valueOf(RentBike.getRentBike().getBike().getTypeBike().getDepositPrice()),
                "Refund Deposit Price For Customer", Configs.CARD_NUMBER.trim(), Configs.CARD_NAME.trim(),
                Configs.EXPIRATION_DATE.trim(), Configs.SECURITY_CODE.trim());
        System.out.println(response.toString());
    }
}
