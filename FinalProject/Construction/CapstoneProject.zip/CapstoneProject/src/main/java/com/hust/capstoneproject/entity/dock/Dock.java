package com.hust.capstoneproject.entity.dock;

import com.hust.capstoneproject.entity.bike.Bike;

import java.sql.Time;
import java.util.ArrayList;
import java.util.List;

public class Dock {
    private int dockId;
    private String name;
    private String address;
    private float area;
    private int numOfAvailableBikes;
    private int numOfAvailableSpaces;
    private float distance;
    private Time walkingTime;
    private List<Bike> bikeList;

    public Dock() {

    }

    public Dock(int dockId, String name, String address, float area, int numOfAvailableBikes, int numOfAvailableSpaces, List<Bike> bikeList) {
        this.dockId = dockId;
        this.name = name;
        this.address = address;
        this.area = area;
        this.numOfAvailableBikes = numOfAvailableBikes;
        this.numOfAvailableSpaces = numOfAvailableSpaces;
        this.bikeList = bikeList;
    }

    public Dock(int dockId, String name, String address, float area, int numOfAvailableBikes, int numOfAvailableSpaces, float distance, Time walkingTime) {
        this.dockId = dockId;
        this.name = name;
        this.address = address;
        this.area = area;
        this.numOfAvailableBikes = numOfAvailableBikes;
        this.numOfAvailableSpaces = numOfAvailableSpaces;
        this.distance = distance;
        this.walkingTime = walkingTime;
    }

    public Dock(String name, String address) {
        this.name = name;
        this.address = address;
    }

    public int getDockId() {
        return dockId;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getAddress() {
        return address;
    }

    public float getArea() {
        return area;
    }

    public void setArea(float area) {
        this.area = area;
    }

    public int getNumOfAvailableBikes() {
        return numOfAvailableBikes;
    }

    public void setNumOfAvailableBikes(int numOfAvailableBikes) {
        this.numOfAvailableBikes = numOfAvailableBikes;
    }

    public int getNumOfAvailableSpaces() {
        return numOfAvailableSpaces;
    }

    public void setNumOfAvailableSpaces(int numOfAvailableSpaces) {
        this.numOfAvailableSpaces = numOfAvailableSpaces;
    }

    public List<Bike> getBikeList() {
        return bikeList;
    }

    public void setBikeList(List<Bike> bikeList) {
        this.bikeList = bikeList;
    }

    public float getDistance() {
        return distance;
    }

    public void setDistance(float distance) {
        this.distance = distance;
    }

    public Time getWalkingTime() {
        return walkingTime;
    }

    public void setWalkingTime(Time walkingTime) {
        this.walkingTime = walkingTime;
    }

    @Override
    public String toString() {
        return "Dock{" +
                "dockId=" + dockId +
                ", name='" + name + '\'' +
                ", address='" + address + '\'' +
                ", area=" + area +
                ", numOfAvailableBikes=" + numOfAvailableBikes +
                ", numOfAvailableSpaces=" + numOfAvailableSpaces +
                ", bikeList=" + bikeList +
                '}';
    }
}
