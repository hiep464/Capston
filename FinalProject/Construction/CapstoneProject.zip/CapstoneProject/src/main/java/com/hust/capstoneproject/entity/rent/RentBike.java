package com.hust.capstoneproject.entity.rent;

import com.hust.capstoneproject.entity.bike.Bike;

import java.time.LocalDateTime;

public class RentBike {
    private int id;
    private Bike bike;
    private LocalDateTime rentalAt;
    private LocalDateTime returnAt;
    private int totalAmount;

    private static RentBike rentBike;

    public static RentBike getRentBike() {
        if (rentBike == null) {
            rentBike = new RentBike();
        }
        return rentBike;
    }

    public void setBike(Bike bike) {
        this.bike = bike;
    }

    public int getId() {
        return id;
    }

    public Bike getBike() {
        return bike;
    }

    public LocalDateTime getRentalAt() {
        return rentalAt;
    }

    public void setRentalAt() {
        this.rentalAt = LocalDateTime.now();
    }

    public void setReturnAt() {
        this.returnAt = LocalDateTime.now();
    }

    public LocalDateTime getReturnAt() {
        return returnAt;
    }

    public int getTotalAmount() {
        return totalAmount;
    }

    public void setTotalAmount(int totalAmount) {
        this.totalAmount = totalAmount;
    }

    @Override
    public String toString() {
        return "RentBike{" +
                "id=" + id +
                ", bike=" + bike +
                ", rentalAt=" + rentalAt +
                ", returnAt=" + returnAt +
                ", totalAmount=" + totalAmount +
                '}';
    }
}
