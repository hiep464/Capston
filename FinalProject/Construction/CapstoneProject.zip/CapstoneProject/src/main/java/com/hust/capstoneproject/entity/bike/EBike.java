package com.hust.capstoneproject.entity.bike;

import com.hust.capstoneproject.entity.typebike.TypeBike;

public class EBike extends Bike{
    private int battery;
    private String licensePlate;

    public EBike() {
        super();
    }

    public EBike(int bikeId, String name, String status, TypeBike typeBike, int dockId, int battery, String licensePlate) {
        super(bikeId, name, status, typeBike, dockId);
        this.battery = battery;
        this.licensePlate = licensePlate;
    }

    public EBike(int bikeId, String name, int dockId, int battery, String licensePlate) {
        super(bikeId, name, dockId);
        this.battery = battery;
        this.licensePlate = licensePlate;
    }

    public int getBattery() {
        return battery;
    }

    public void setBattery(int battery) {
        this.battery = battery;
    }

    public String getLicensePlate() {
        return licensePlate;
    }

    public void setLicensePlate(String licensePlate) {
        this.licensePlate = licensePlate;
    }

    @Override
    public String toString() {
        return "EBike{" +
                "bikeId=" + bikeId +
                ", name='" + name + '\'' +
                ", typeBike=" + typeBike +
                ", dockId=" + dockId +
                ", battery=" + battery +
                ", licensePlate='" + licensePlate + '\'' +
                '}';
    }
}
