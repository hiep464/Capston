package com.hust.capstoneproject.controller;

import com.hust.capstoneproject.dao.bike.BikeDAO;
import com.hust.capstoneproject.dao.dock.DockDAO;
import com.hust.capstoneproject.dao.rent.RentBikeDAO;
import com.hust.capstoneproject.entity.dock.Dock;
import com.hust.capstoneproject.entity.rent.RentBike;
import com.hust.capstoneproject.utils.calculatefees.CalculateFees;

import java.util.List;

public class ReturnBikeController extends BaseController{
    private DockDAO dockDAO = DockDAO.getDockDAO();
    private BikeDAO bikeDAO = BikeDAO.getBikeDAO();
    private RentBikeDAO rentBikeDAO = RentBikeDAO.getRentBikeDAO();
    private CalculateFees calculateFees;

    public void setCalculateFees(CalculateFees calculateFees) {
        this.calculateFees = calculateFees;
    }

    public int calRentedFees(RentBike rentBike) {
        return calculateFees.calculateRentedFees(rentBike);
    }

    public List<Dock> getAllDockToReturnBike() {
        return dockDAO.getAllDock();
    }

    public boolean updateBikeAfterReturn(int bikeId, int dockId) {
        return bikeDAO.updateBikeAfterReturn(bikeId, dockId);
    }

    public boolean insertRentBike(RentBike rentBike){
        return rentBikeDAO.insertRentBike(rentBike);
    }
}
