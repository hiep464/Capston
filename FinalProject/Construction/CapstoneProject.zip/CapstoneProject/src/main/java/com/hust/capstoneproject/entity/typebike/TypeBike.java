package com.hust.capstoneproject.entity.typebike;

public class TypeBike {
    private int typeId;
    private String typeName;
    private int depositPrice;

    public TypeBike() {

    }

    public TypeBike(String typeName) {
        this.typeName = typeName;
    }

    public TypeBike(int typeId, String typeName, int depositPrice) {
        this.typeId = typeId;
        this.typeName = typeName;
        this.depositPrice = depositPrice;
    }

    public int getTypeId() {
        return typeId;
    }

    public String getTypeName() {
        return typeName;
    }

    public int getDepositPrice() {
        return depositPrice;
    }

    @Override
    public String toString() {
        return "TypeBike{" +
                "typeId=" + typeId +
                ", typeName='" + typeName + '\'' +
                ", depositPrice=" + depositPrice +
                '}';
    }
}
