package com.hust.capstoneproject.dao.dock;

import com.hust.capstoneproject.entity.bike.Bike;
import com.hust.capstoneproject.entity.db.DBConnect;
import com.hust.capstoneproject.entity.dock.Dock;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

public class DockDAO {
    private static final String TABLE_DOCK = "dock";

    private static DockDAO dockDAO;

    public static DockDAO getDockDAO() {
        if (dockDAO == null) {
            dockDAO = new DockDAO();
        }
        return dockDAO;
    }

    public List<Dock> getAllDock() {
        List<Dock> listDock = new ArrayList<>();
        Statement statement = null;
        try {
            Connection connect = DBConnect.getConnection();
            String sql = "select * from " + TABLE_DOCK;
            statement = connect.createStatement();

            ResultSet result = statement.executeQuery(sql);
            try {
                while (result.next()) {
                    Dock dock = new Dock(result.getInt("dock_id"), result.getString("dock_name").trim(),
                            result.getString("dock_address").trim(), result.getFloat("area"),
                            result.getInt("num_of_available_bikes"), result.getInt("num_of_available_spaces"),
                            result.getFloat("distance"), result.getTime("walking_time"));
                    listDock.add(dock);
                }
            } finally {
                closeResultSet(result);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            closeStatement(statement);
        }
        return listDock;
    }

    public List<Dock> getDockByNameAndAddress(String address, String name) {
        List<Dock> listDock = new ArrayList<>();
        Statement statement = null;
        try {
            Connection connect = DBConnect.getConnection();
//            String sql = "select * from " + TABLE_DOCK + " where LOWER(dock_address) LIKE LOWER('%" + address + "%') and LOWER(dock_name) LIKE LOWER('%" + name + "%')";
            String sql = "select * from dock where dock_address ILIKE '%" + address + "%' and dock_name ILIKE '%" + name + "%'";
            statement = connect.createStatement();

            ResultSet result = statement.executeQuery(sql);
            try {
                while (result.next()) {
                    Dock dock = new Dock(result.getInt("dock_id"), result.getString("dock_name").trim(),
                            result.getString("dock_address").trim(), result.getFloat("area"),
                            result.getInt("num_of_available_bikes"), result.getInt("num_of_available_spaces"),
                            result.getFloat("distance"), result.getTime("walking_time"));
                    listDock.add(dock);
                }
            } finally {
                closeResultSet(result);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            closeStatement(statement);
        }
        return listDock;
    }

    private void closeResultSet(ResultSet result) {
        try {
            result.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void closeStatement(Statement statement) {
        try {
            if (statement != null)
                statement.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public static void main(String[] args) {
        for (Dock dock : new DockDAO().getAllDock()) {
            System.out.println(dock.toString());
        }
    }
}
