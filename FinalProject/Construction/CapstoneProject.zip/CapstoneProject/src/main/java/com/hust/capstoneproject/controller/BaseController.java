package com.hust.capstoneproject.controller;

public class BaseController {
}
