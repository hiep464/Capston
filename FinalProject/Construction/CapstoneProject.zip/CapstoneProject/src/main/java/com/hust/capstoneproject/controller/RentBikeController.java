package com.hust.capstoneproject.controller;

import com.hust.capstoneproject.dao.bike.BikeDAO;
import com.hust.capstoneproject.dao.rent.RentBikeDAO;
import com.hust.capstoneproject.entity.bike.Bike;
import com.hust.capstoneproject.entity.rent.RentBike;

public class RentBikeController extends BaseController{
    private BikeDAO bikeDAO = BikeDAO.getBikeDAO();

    public boolean updateBikeStatus(Bike bike) {
        return bikeDAO.updateBikeStatus(bike);
    }
}
