package com.hust.capstoneproject.entity.payment;

public class PaymentTransaction {
    private String errorCode;
    private CreditCard card;
    private String transactionId;
    private String transactionContent;
    private String amount;
    private String createdAt;

    public PaymentTransaction(String errorCode, CreditCard card, String transactionId, String transactionContent,
                              String amount, String createdAt) {
        super();
        this.errorCode = errorCode;
        this.card = card;
        this.transactionId = transactionId;
        this.transactionContent = transactionContent;
        this.amount = amount;
        this.createdAt = createdAt;
    }

    public PaymentTransaction(String errorCode) {
        this.errorCode = errorCode;
    }

    @Override
    public String toString() {
        return "PaymentTransaction{" +
                "errorCode='" + errorCode + '\'' +
                ", card=" + card +
                ", transactionId='" + transactionId + '\'' +
                ", transactionContent='" + transactionContent + '\'' +
                ", amount='" + amount + '\'' +
                ", createdAt='" + createdAt + '\'' +
                '}';
    }

    public String getErrorCode() {
        return errorCode;
    }
}