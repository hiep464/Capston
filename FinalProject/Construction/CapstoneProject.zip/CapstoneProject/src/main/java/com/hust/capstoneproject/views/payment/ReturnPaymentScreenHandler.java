package com.hust.capstoneproject.views.payment;

import com.hust.capstoneproject.controller.PaymentController;
import com.hust.capstoneproject.utils.Configs;
import com.hust.capstoneproject.views.BaseScreenHandler;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.CheckBox;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.stage.Stage;

import java.io.IOException;
import java.util.Map;

public class ReturnPaymentScreenHandler extends BaseScreenHandler {

    @FXML
    private Button btn_confirm;

    @FXML
    private CheckBox newCardButton;

    @FXML
    private TextArea ta_content;

    @FXML
    private TextField tf_ExDate;

    @FXML
    private TextField tf_cardname;

    @FXML
    private TextField tf_cardnum;

    @FXML
    private TextField tf_secucode;

    public PaymentController getBController() {
        return (PaymentController) super.getBController();
    }

    private int rentalFees;
    private int depositPrice;

    public ReturnPaymentScreenHandler(Stage stage, String screenPath, int depositPrice, int rentalFees) throws IOException {
        super(stage, screenPath);
        this.rentalFees = rentalFees;
        this.depositPrice = depositPrice;
        setBController(new PaymentController());

        btn_confirm.setOnMouseClicked(e -> {
            try {
                confirmToPayMoney();
            } catch (IOException ex) {
                ex.printStackTrace();
            }
        });
    }

    public void confirmToPayMoney() throws IOException {
        PaymentController ctrl = this.getBController();
        Map<String, String> response = ctrl.payOrder(String.valueOf(rentalFees), ta_content.getText().trim(),
                tf_cardnum.getText().trim(), tf_cardname.getText().trim(), tf_ExDate.getText().trim(), tf_secucode.getText().trim());
        System.out.println(response.toString());
        BaseScreenHandler resultScreen = new ReturnResultScreenHandler(this.stage, "/com/hust/capstoneproject/ReturnResultScreen.fxml",
                response.get("RESULT"), response.get("MESSAGE"));
        resultScreen.setPreviousScreen(this);
        resultScreen.setScreenTitle("Result Screen");
        resultScreen.show();
    }
}
