package com.hust.capstoneproject.views.bike;

import com.hust.capstoneproject.views.BaseScreenHandler;
import com.hust.capstoneproject.controller.ViewBikeController;
import com.hust.capstoneproject.dao.bike.EBikeDAO;
import com.hust.capstoneproject.entity.bike.Bike;
import com.hust.capstoneproject.entity.bike.EBike;
import com.hust.capstoneproject.utils.Configs;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.stage.Stage;

import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;

/**
 * @author HH
 */
public class BikeScreenHandler extends BaseScreenHandler implements Initializable{
    @FXML
    private Button btn_back;

    @FXML
    private Label lb_battery;

    @FXML
    private Label lb_btr;

    @FXML
    private Label lb_lspl;

    @FXML
    private Label lb_mein;

    @FXML
    private Label lb_price;

    @FXML
    private Label lb_type;

    @FXML
    private Label lp_label;

    private Bike bike;

    public ViewBikeController getBController() {
        return (ViewBikeController) super.getBController();
    }

    public BikeScreenHandler(Stage stage, String screenPath, Bike bike) throws IOException {
        super(stage, screenPath);
        setBController(new ViewBikeController());
        this.bike = bike;
        setBikeInfo();
    }

    public void setBikeInfo(){
        lb_type.setText(bike.getTypeBike().getTypeName());
        lb_price.setText(String.valueOf(bike.getTypeBike().getDepositPrice()));
        if (bike.getTypeBike().getTypeId() == Configs.EBIKE_ID) {
            bike = this.getBController().getEBikeByBikeId(bike.getBikeId());
            lb_lspl.setText(((EBike)bike).getLicensePlate());
            lb_btr.setText(((EBike)bike).getBattery() + "%");
            lp_label.setVisible(true);
            lb_btr.setVisible(true);
            lb_lspl.setVisible(true);
            lb_battery.setVisible(true);
        }
    }

    @Override
    public void show() {
        super.show();
    }

    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
        btn_back.setOnMouseClicked(e->{
            this.getPreviousScreen().show();
        });
    }
}
